#!/bin/bash
cp -r /tmp/kde-bedahr/sam/internalsamuser/compile /mnt/data/models/$1__`date +"%Y%m%d"`

