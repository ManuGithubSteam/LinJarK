#!/bin/bash
rm -rf ~/.kde4/share/apps/simon
rm -rf ~/.kde4/share/apps/simond
rm -rf ~/.kde4/share/apps/ksimond
rm ~/.kde4/share/config/*simon*
rm ~/.kde4/share/config/*speech*
rm ~/.kde4/share/apps/knewstuff3/simonscenarios.knsregistry
