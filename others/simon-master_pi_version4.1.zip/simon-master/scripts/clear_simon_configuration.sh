#!/bin/bash
rm ~/.kde4/share/config/{simonrc,simonmodelcompilationrc,simonrecognitionrc,simonscenariosrc,simonsoundrc,speechmodelmanagementrc} ;
rm -r ~/.kde4/share/apps/{simon,simond}
