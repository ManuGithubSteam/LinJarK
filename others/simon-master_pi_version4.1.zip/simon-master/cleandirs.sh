#!/bin/bash
find . -iname "*~" -exec rm {} \;
