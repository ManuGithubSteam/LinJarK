This plugin contains no real logic and as such is a possible base for a new plugin.
