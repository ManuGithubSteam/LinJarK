#!/bin/bash

cat scenarioSPACHERKENNUNG.scenario | sed 's#.linjark#'"$HOME.linjark"'#' > 1.tmp

mv 1.tmp scenarioSPACHERKENNUNG.scenario